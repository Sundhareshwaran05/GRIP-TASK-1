      <!-- footer part start -->
      <footer class="py-3 my-4">
        <ul class="nav justify-content-center border-bottom pb-3 mb-3">
          <li class="nav-item"><a href="index.php" class="nav-link px-2 text-muted">Home</a></li>
          <li class="nav-item"><a href="customer.php" class="nav-link px-2 text-muted">View all Customers</a></li>
          <li class="nav-item"><a href="index.php#About" class="nav-link px-2 text-muted">About</a></li>
        </ul>
        <p class="text-center text-muted">© 2021 Money Bank, Inc</p>
      </footer>
      <!-- footer part end -->